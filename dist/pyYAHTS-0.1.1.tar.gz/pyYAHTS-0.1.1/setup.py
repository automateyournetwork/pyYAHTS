# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['pyYAHTS']

package_data = \
{'': ['*']}

install_requires = \
['rich-click>=1.2.1,<2.0.0', 'rich>=12.0.1,<13.0.0']

setup_kwargs = {
    'name': 'pyyahts',
    'version': '0.1.1',
    'description': 'An interpretation, extension, and implementation of Cisco pyATS',
    'long_description': None,
    'author': 'John Capobianco',
    'author_email': 'ptcapo@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/automateyournetwork/pyYAHTS',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
