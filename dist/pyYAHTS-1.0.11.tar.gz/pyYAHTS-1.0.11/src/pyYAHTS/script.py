import sys
from .pyYAHTS import cli
def run():
    cli()